# Local Business Lead Finder

Find small businesses with slow or non-mobile websites, grab their public contact email, and measure their site with Google Lighthouse — so your outreach opens with a real number ("your site scores 38/100 on mobile") instead of a generic pitch.

Built for freelancers and small agencies selling web design, speed optimisation, SEO, or automation.

## What it does

1. `scrape.mjs` — runs a search query (e.g. `plumber Toledo Ohio`), visits each result site, pulls public emails from the home/contact/about pages, and records quality signals: HTTPS, mobile viewport, copyright year, site builder (Wix/WordPress/Shopify/GoDaddy/custom), jQuery 1.x, table layouts, WhatsApp presence, phone number. Directories, marketplaces and social sites are filtered out. Each site is scored (higher = weaker site = better prospect).
2. `audit.mjs` — runs Lighthouse (mobile) on every lead with an email and stores performance/SEO/accessibility scores, LCP, TBT, CLS and page weight.
3. `compose.mjs` — turns leads + audits into personalised email drafts (subject + body) with the right offer per site, ready to send from any mail client or API. Edit the template strings to match your services and prices.

Output is newline-delimited JSON (`leads.jsonl`, `audits.jsonl`, `queue.jsonl`) so you can open it in a spreadsheet, pipe it to `jq`, or load it anywhere.

## Requirements

- Node.js 18+ (uses built-in `fetch`)
- Chrome or Chromium installed (for Lighthouse)
- `npm install lighthouse`

No API keys. No paid search service. Search uses DuckDuckGo's HTML endpoint.

## Usage

```bash
npm install lighthouse
node scrape.mjs "roofing contractor Fort Wayne Indiana" 15      # 15 sites max
node scrape.mjs "dentist Boise Idaho" 15
node audit.mjs 50                                              # audit up to 50 leads
node compose.mjs                                               # write outreach/queue.jsonl
```

Batch many queries:

```bash
while read -r q; do node scrape.mjs "$q" 15; done < queries.txt
```

A `queries.txt` with 40 tested US/UK/CA/AU trade + city combinations is included.

## Tips that actually matter

- Query pattern that works: `<trade> <mid-size city> <state>`. Big cities return directories; small towns return real business sites.
- Only email sites that score under 70 on mobile or lack a viewport tag. Decent sites do not need you, and pitching them hurts deliverability.
- Send 30–50 personalised emails a day per mailbox, not more. Include a one-line opt-out.
- Lead with the number. "Your site scores 41/100 on mobile and takes 6.8s to show content" gets replies; "I noticed your website could use improvement" does not.

## Licence

Personal and commercial use by the purchaser. Do not resell or redistribute the scripts themselves.
