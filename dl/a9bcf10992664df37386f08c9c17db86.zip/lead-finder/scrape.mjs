// Lead scraper: Bing search -> candidate sites -> extract emails + quality signals.
// Usage: node scrape.mjs "query" [maxResults]
import fs from 'node:fs';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/128 Safari/537.36';
const SKIP = /indiamart|tradeindia|justdial|sulekha|exportersindia|facebook|instagram|linkedin|youtube|wikipedia|amazon|flipkart|yelp|yellowpages|google\.|bing\.|glassdoor|indeed|quora|reddit|twitter|x\.com|zomato|swiggy|magicbricks|99acres|olx|bbb\.org|mapquest|angi\.com|thumbtack|houzz|nextdoor|manta\.com|chamberofcommerce|dnb\.com|zoominfo|crunchbase|apollo\.io|opencorporates|tofler|zaubacorp|myntra|ajio|meesho|alibaba|made-in-china|etsy|ebay|walmart|tiktok|pinterest|bing\.com|microsoft|apple\.com|yellowpages|tripadvisor|practo|lybrate|shiksha|collegedunia|justdial|urbanpro|nobroker|housing\.com|squareyards|ambitionbox|naukri|glassdoor|kompass|cybo|dnb|hotfrog|brownbook|yalwa|infoisinfo|city-vibes|cityvibes|businesslist|indiabizlist|fundoodata|3pl|tofler|economictimes|timesofindia|tribuneindia|hindustantimes|dailypost|jagran|bhaskar|news18|ndtv|thehindu|indiatoday|business-standard|livemint|moneycontrol|linkedin|blogspot|wordpress\.com|medium\.com|govt?\.|nic\.in|gov\.in|edu$/i;
const q = process.argv[2]; const max = +(process.argv[3] || 25);
const out = process.argv[4] || 'leads.jsonl';
async function get(url, ms = 12000) {
  const c = new AbortController(); const t = setTimeout(() => c.abort(), ms);
  try { const r = await fetch(url, { headers: { 'user-agent': UA, 'accept-language': 'en' }, signal: c.signal, redirect: 'follow' }); const txt = await r.text(); return { status: r.status, url: r.url, txt }; }
  catch (e) { return { status: 0, url, txt: '', err: String(e.message || e) }; } finally { clearTimeout(t); }
}
async function ddg(query) {
  const urls = new Set();
  const r = await get('https://lite.duckduckgo.com/lite/?q=' + encodeURIComponent(query));
  for (const m of r.txt.matchAll(/uddg=([^&"]+)/g)) {
    try { const u = new URL(decodeURIComponent(m[1])); if (/^https?:$/.test(u.protocol) && !SKIP.test(u.hostname)) urls.add(u.origin); } catch {}
  }
  return [...urls];
}
const seen = new Set(fs.existsSync(out) ? fs.readFileSync(out, 'utf8').split('\n').filter(Boolean).map(l => JSON.parse(l).site) : []);
const sites = (await ddg(q)).filter(s => !seen.has(s)).slice(0, max);
console.error(`[${q}] ${sites.length} new candidate sites`);
for (const site of sites) {
  const home = await get(site);
  if (!home.txt) { continue; }
  const pages = [home];
  const contactLinks = [...home.txt.matchAll(/href="([^"]*(contact|about|reach)[^"]*)"/gi)].map(m => m[1]).slice(0, 3);
  for (const l of contactLinks) { try { pages.push(await get(new URL(l, home.url).href)); } catch {} }
  const emails = new Set();
  for (const p of pages) for (const m of p.txt.matchAll(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g)) {
    const e = m[0].toLowerCase(); if (!/\.(png|jpg|jpeg|gif|svg|webp|css|js)$/.test(e) && !/example|sentry|wixpress|domain\.com|email\.com|yourdomain|@2x|godaddy|wordpress\.org/.test(e)) emails.add(e);
  }
  const h = home.txt;
  const title = (h.match(/<title[^>]*>([^<]*)</i) || [, ''])[1].trim().replace(/\s+/g, ' ').slice(0, 120);
  const signals = {
    https: home.url.startsWith('https'),
    viewport: /<meta[^>]+name=["']viewport/i.test(h),
    year: (h.match(/(?:©|&copy;|copyright)\s*(?:\d{4}\s*-\s*)?(20\d\d)/i) || [, ''])[1],
    builder: /wix\.com|wixstatic/i.test(h) ? 'wix' : /wp-content/i.test(h) ? 'wordpress' : /shopify/i.test(h) ? 'shopify' : /godaddy|secureserver/i.test(h) ? 'godaddy' : /squarespace/i.test(h) ? 'squarespace' : /indiamart|imimg\.com/i.test(h) ? 'indiamart-mini' : 'custom',
    jquery1: /jquery[-.]1\.\d/i.test(h), tables: (h.match(/<table/gi) || []).length, sizeKB: Math.round(h.length / 1024),
    whatsapp: /wa\.me|whatsapp/i.test(h), phone: (h.match(/(?:\+91[-\s]?)?[6-9]\d{9}/) || [, ''])[0] || (h.match(/\(?\d{3}\)?[-.\s]\d{3}[-.\s]\d{4}/) || [''])[0]
  };
  const score = (!signals.viewport ? 4 : 0) + (!signals.https ? 3 : 0) + (signals.year && +signals.year < 2022 ? 2 : 0) + (signals.jquery1 ? 1 : 0) + (signals.tables > 3 ? 1 : 0) + (emails.size ? 0 : -10);
  const rec = { q, site, title, emails: [...emails].slice(0, 5), ...signals, score, ts: new Date().toISOString() };
  fs.appendFileSync(out, JSON.stringify(rec) + '\n');
  console.error(`${score >= 0 ? '+' : '-'} ${score} ${site} ${title.slice(0, 50)} ${[...emails][0] || ''}`);
}
