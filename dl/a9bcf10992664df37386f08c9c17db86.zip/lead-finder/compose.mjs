// Compose personalized cold emails from leads + audits. Outputs queue.jsonl (unsent).
import fs from 'node:fs';
const leads = fs.readFileSync('leads.jsonl','utf8').split('\n').filter(Boolean).map(l=>JSON.parse(l));
const audits = Object.fromEntries(fs.readFileSync('audits.jsonl','utf8').split('\n').filter(Boolean).map(l=>JSON.parse(l)).filter(a=>a.ok).map(a=>[a.site,a]));
const sent = new Set(fs.existsSync('sent.jsonl') ? fs.readFileSync('sent.jsonl','utf8').split('\n').filter(Boolean).map(l=>JSON.parse(l).email) : []);
const JUNK = /forbes|gq\.com|esquire|fashionbeans|wiktionary|expertise\.com|threebestrated|plumint|biddaro|dentee|defindia|def\.org|mensoutfits|webfx|newyorker|hearst|facebook\.com$/i;
const BADMAIL = /noreply|no-reply|privacy|abuse|dmca|legal|press|careers|jobs|hr@|billing|sponsorship|webmaster@|postmaster|support@(?!.*)/i;
const INDIA = /\.in$|ludhiana|jalandhar|chandigarh|amritsar|tirupur|jodhpur|moradabad|baddi/i;
const out = [];
for (const l of leads) {
  if (l.score < 0 || !l.emails.length || JUNK.test(l.site) || JUNK.test(l.emails[0])) continue;
  const email = l.emails.find(e => !BADMAIL.test(e) && !/facebook|gmail\.com$/.test(e.split('@')[1]) ) || l.emails.find(e=>!BADMAIL.test(e)); if (!email || sent.has(email)) continue;
  const a = audits[l.site]; if (!a) continue;
  const name = l.title.split(/[|\-–:•]/)[0].trim().replace(/&amp;/g,'&').slice(0,60) || new URL(l.site).hostname;
  const india = INDIA.test(l.site) || INDIA.test(l.q);
  const slow = a.perf < 70, veryslow = a.perf < 50;
  const noMobile = !l.viewport;
  // pick offer
  let offer, price, link;
  if (noMobile || veryslow) { offer = 'rebuild'; price = india ? '₹3,999' : '$149'; link = 'https://your-checkout-link.example'; }
  else if (slow) { offer = 'speed'; price = india ? '₹2,499' : '$79'; link = 'https://your-checkout-link.example'; }
  else continue; // decent site: skip, do not spam
  const first = `Hi ${name} team,`;
  const hook = noMobile
    ? `I opened ${new URL(l.site).hostname} on my phone and the layout does not adapt to a mobile screen (no responsive viewport), so visitors have to pinch and zoom. Google also ranks non-mobile sites lower.`
    : `I ran ${new URL(l.site).hostname} through Google's PageSpeed test on mobile: it scores ${a.perf}/100 and the main content takes ${a.lcp}s to appear (Google's target is under 2.5s). Most visitors on phones leave after about 3 seconds.`;
  const pitch = offer === 'rebuild'
    ? `I build fast one-page business sites that load in under a second and work on every phone: ${price} fixed, delivered in 24 hours, you own the code, no monthly fees. Two examples built this week: https://your-portfolio.example and https://your-portfolio.example`
    : `I fix exactly this for ${price} fixed, within 48 hours, with a before/after PageSpeed report. Works on WordPress, Wix, Shopify and hand-coded sites. Nothing changes in how your site looks.`;
  const cta = india
    ? `If useful, reply to this email and I will send a UPI payment request and start the same day. No call needed.`
    : `If useful, order here and I start the same day: ${link} — or just reply and I will answer any question first.`;
  const body = `${first}\n\n${hook}\n\n${pitch}\n\n${cta}\n\nRegards,\nYour Studio Name\nyou@yourdomain.com · https://your-portfolio.example this is not relevant, reply "no" and I will not write again.`;
  const subject = noMobile ? `${new URL(l.site).hostname} on a phone` : `${new URL(l.site).hostname} scores ${a.perf}/100 on mobile`;
  out.push({ email, site: l.site, name, offer, price, perf: a.perf, lcp: a.lcp, subject, body });
}
fs.writeFileSync('queue.jsonl', out.map(o=>JSON.stringify(o)).join('\n')+'\n');
console.log(`${out.length} emails queued`);
