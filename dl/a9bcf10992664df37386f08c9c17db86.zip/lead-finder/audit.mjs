// Run Lighthouse mobile perf on leads with emails; append results to audits.jsonl
import fs from 'node:fs'; import { execSync, spawnSync } from 'node:child_process';
const exe = execSync('command -v chromium').toString().trim();
const done = new Set(fs.existsSync('audits.jsonl') ? fs.readFileSync('audits.jsonl','utf8').split('\n').filter(Boolean).map(l=>JSON.parse(l).site) : []);
const leads = fs.readFileSync('leads.jsonl','utf8').split('\n').filter(Boolean).map(l=>JSON.parse(l)).filter(l=>l.emails.length && l.score>=0 && !done.has(l.site));
const limit = +(process.argv[2]||50);
for (const l of leads.slice(0, limit)) {
  const out = `./lh-${Date.now()}.json`;
  const r = spawnSync('npx', ['lighthouse', l.site, '--only-categories=performance,seo,accessibility', '--form-factor=mobile', '--screenEmulation.mobile', '--quiet', '--output=json', `--output-path=${out}`, `--chrome-flags=--headless=new --no-sandbox --disable-gpu`], { env: { ...process.env, CHROME_PATH: exe }, timeout: 120000, encoding: 'utf8' });
  let rec = { site: l.site, ok: false };
  try { const j = JSON.parse(fs.readFileSync(out,'utf8')); const a = j.audits; rec = { site: l.site, ok: true, perf: Math.round(j.categories.performance.score*100), seo: Math.round(j.categories.seo.score*100), a11y: Math.round(j.categories.accessibility.score*100), lcp: +(a['largest-contentful-paint'].numericValue/1000).toFixed(1), tbt: Math.round(a['total-blocking-time'].numericValue), cls: +a['cumulative-layout-shift'].numericValue.toFixed(2), bytesKB: Math.round(a['total-byte-weight'].numericValue/1024), title: j.finalDisplayedUrl }; fs.unlinkSync(out); } catch (e) { rec.err = (r.stderr||'').slice(-200); }
  fs.appendFileSync('audits.jsonl', JSON.stringify(rec)+'\n'); console.log(JSON.stringify(rec));
}
